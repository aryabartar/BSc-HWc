/**
 * UndergraduateStudent class represents totalCourses , ration and extends Student class .
 *
 * @author Arya Khaligh
 * @version 1.0
 */
public class UndergraduateStudent extends Student {

    private final int totalCourses = 140;
    private String ration; //sahmiye !

    /**
     * This constructor initializes first name , last name , student ID , totalCourses and ration .
     *
     * @param firstName
     * @param lastName
     * @param studentId
     * @param ration
     */
    public UndergraduateStudent(String firstName, String lastName, int studentId, String ration) {
        super(firstName, lastName, studentId);
        if (ration == "konkour" || ration == "olympiad" || ration == "heyate elmy daem" ||
                ration == "heyate elmy moveghat" || ration == "mihman")
            this.ration = ration;
        else
            throw new IllegalArgumentException("Wrong ration !");
    }

    /**
     * GetRation method returns private ration field .
     *
     * @return ration
     */
    public String getRation() {
        return ration;
    }

    /**
     * SetRation method sets private ration field .
     *
     * @param ration
     */
    public void setRation(String ration) {
        if (ration == "konkour" || ration == "olympiad" || ration == "heyate elmy daem" ||
                ration == "heyate elmy moveghat" || ration == "mihman")
            this.ration = ration;
        else
            throw new IllegalArgumentException("Wrong ration!");
    }

    /**
     * GetTotalCourses method returns private totalCourses field .
     *
     * @return totalCourses
     */
    public int getTotalCourses() {
        return totalCourses;
    }

    /**
     * This method overrides displayStudentInformation method in Student class .
     */
    @Override
    public void displayStudentInformation() {
        super.displayInfo();
        System.out.println("Total courses : " + totalCourses + "    Ration : " + ration);
    }


}
