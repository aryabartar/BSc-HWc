/**
 * Student is an abstract class and super class of GraduateStudent and UndergraduateStudent classes .
 *
 * @author Arya Khaligh
 * @version 1.0
 */
public abstract class Student {
    private String firstName;
    private String lastName;
    private int studentId;

    /**
     * This constructor initializes first name , last name and student ID .
     *
     * @param firstName
     * @param lastName
     * @param studentId
     */
    public Student(String firstName, String lastName, int studentId) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.studentId = studentId;
    }

    /**
     * GetFirstName method returns student firstName private field .
     *
     * @return firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * GetLastName method returns student lastName private field .
     *
     * @return lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * GetStudentId method returns student studentId private field .
     *
     * @return studentId
     */
    public int getStudentId() {
        return studentId;
    }

    /**
     * SetFirstName method sets student firstName private field .
     *
     * @param firstName
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * SetLastName method sets student lastName private field .
     *
     * @param lastName
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * SetStudentId method sets student studentId private field .
     *
     * @param studentId
     */
    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    /**
     * DisplayInfo prints all Student class fields .
     */
    public void displayInfo() {
        System.out.println("First name : " + getFirstName() + "    Last name : " + getLastName() +
                "    Student ID : " + getStudentId());
    }

    /**
     * This method is abstract .
     */
    public abstract void displayStudentInformation();

}
