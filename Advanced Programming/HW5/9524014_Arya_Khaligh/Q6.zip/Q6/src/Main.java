/**
 * This class makes UndergraduateStudent and GraduateStudent objects and uses them .
 *
 * @author Arya Khaligh
 * @version 1.0
 * @since 2018/03/16
 */
public class Main {
    public static void main(String args[]) {
        UndergraduateStudent undergraduateStudent1 = new UndergraduateStudent("Arya", "Khaligh", 9524014, "konkour");
        UndergraduateStudent undergraduateStudent2 = new UndergraduateStudent("Arshiya", "Khaligh", 9511022, "mihman");
        GraduateStudent graduateStudent1 = new GraduateStudent("Ali", "Jafari", 9322055, "Dr.Faridi", "Azaad");
        GraduateStudent graduateStudent2 = new GraduateStudent("Poopak", "Khaaki", 9033054, "Dr.Bakhshi", "Sharif");

        System.out.println(undergraduateStudent1.getRation());
        System.out.println(undergraduateStudent1.getFirstName());
        System.out.println(undergraduateStudent1.getLastName());
        System.out.println(undergraduateStudent1.getStudentId());
        System.out.println(undergraduateStudent1.getTotalCourses());
        undergraduateStudent1.displayStudentInformation();
        undergraduateStudent1.setRation("mihman");
        undergraduateStudent1.setFirstName("Arya1");
        undergraduateStudent1.setLastName("Khaligh1");
        undergraduateStudent1.setStudentId(9524015);
        System.out.println("\n\n");
        undergraduateStudent1.displayStudentInformation();
        System.out.println("\n\n");
        undergraduateStudent2.displayStudentInformation();
        System.out.println("\n******************\n");

        System.out.println(graduateStudent1.getPreviousUniversityName());
        System.out.println(graduateStudent1.getSupervisor());
        System.out.println(graduateStudent1.getCourses());
        System.out.println(graduateStudent1.getFirstName());
        System.out.println(graduateStudent1.getLastName());
        System.out.println(graduateStudent1.getStudentId());
        graduateStudent1.displayStudentInformation();
        graduateStudent1.setPreviousUniversityName("Azad1");
        graduateStudent1.setSupervisor("Dr.Mofidi");
        graduateStudent1.setFirstName("Ali1");
        graduateStudent1.setLastName("Jafari1");
        graduateStudent1.setStudentId(8911011);
        System.out.println("\n\n");
        graduateStudent1.displayStudentInformation();
        System.out.println("\n\n");
        graduateStudent2.displayStudentInformation();
        System.out.println("******************");

    }
}
