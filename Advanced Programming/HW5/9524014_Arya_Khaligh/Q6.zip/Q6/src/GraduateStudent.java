/**
 * GraduateStudent class represents courses , supervisor , previousUniversityName and extends Student class .
 *
 * @author Arya Khaligh
 * @version 1.0
 */
public class GraduateStudent extends Student {
    private final int courses = 32;
    private String supervisor;
    private String previousUniversityName;

    /**
     * This constructor initializes first name , last name , student ID , supervisor and previousUniversityName .
     *
     * @param firstName
     * @param lastName
     * @param studentId
     * @param supervisor
     * @param previousUniversityName
     */

    public GraduateStudent(String firstName, String lastName, int studentId, String supervisor, String previousUniversityName) {
        super(firstName, lastName, studentId);
        this.supervisor = supervisor;
        this.previousUniversityName = previousUniversityName;
    }

    /**
     * GetSupervisor method returns private supervisor field .
     *
     * @return suprvisor
     */
    public String getSupervisor() {
        return supervisor;
    }

    /**
     * GetPreviousUniversityName method returns private previousUniversityName field .
     *
     * @return previousUniversityName
     */
    public String getPreviousUniversityName() {
        return previousUniversityName;
    }

    /**
     * SetSupervisor method sets private supervisor field .
     *
     * @param supervisor
     */
    public void setSupervisor(String supervisor) {
        this.supervisor = supervisor;
    }

    /**
     * setPreviousUniversityName method sets private previousUniversityName field .
     *
     * @param previousUniversityName
     */
    public void setPreviousUniversityName(String previousUniversityName) {
        this.previousUniversityName = previousUniversityName;
    }

    /**
     * GetCourses returns courses private final field .
     *
     * @return
     */
    public int getCourses() {
        return courses;
    }

    /**
     * This method overrides displayStudentInformation method in Student class .
     */
    @Override
    public void displayStudentInformation() {
        super.displayInfo();
        System.out.println("    Total courses : " + courses + "    Supervisor : " + getSupervisor()
                + "    Perivious university name : " + getPreviousUniversityName());
    }
}
