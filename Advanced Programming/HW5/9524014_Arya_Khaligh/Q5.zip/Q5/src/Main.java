/**
 *  We create two objects and add them to bank object .
 *
 *  @author Arya Khaligh
 *  @version 1.0
 */
public class Main {
    public static void main (String args[]) {
        Bank bank = new Bank() ;
        SavingsAccount savingsAccount1 = new SavingsAccount(10001 , 0.1) ;
        SavingsAccount savingsAccount2 = new SavingsAccount(10002 , 0.05) ;
        SavingsAccount savingsAccount3 = new SavingsAccount(10003 , 0.2) ;
        CurrentAccount currentAccount1 = new CurrentAccount(11001 , 100) ;
        CurrentAccount currentAccount2 = new CurrentAccount(11002 , 200) ;
        CurrentAccount currentAccount3 = new CurrentAccount(11003 , 50 ) ;

        savingsAccount1.deposit(200);
        savingsAccount2.deposit(300);
        savingsAccount3.deposit(100);

        bank.addAccount(savingsAccount1);
        bank.addAccount(savingsAccount2);
        bank.addAccount(savingsAccount3);
        bank.addAccount(currentAccount1);
        bank.addAccount(currentAccount2);
        bank.addAccount(currentAccount3);

        bank.update();

//        printing savingsAccount1:
        System.out.println("\n---------#1---------");
        savingsAccount1.print();
        System.out.println(savingsAccount1.toString());

        System.out.println("\n---------#2---------");
        System.out.println(savingsAccount1.getInterestRate());
        savingsAccount1.depositInterestRate();
        savingsAccount1.print();

        System.out.println("\n---------#3---------");
        savingsAccount1.deposit(10);
        savingsAccount1.print();
        savingsAccount1.withdraw(10);
        savingsAccount1.print();
        System.out.println(savingsAccount1.getAccountNumber());

        System.out.println("\n---------#4---------");
        currentAccount1.print();
        currentAccount1.deposit(110);
        currentAccount1.withdraw(9);
        currentAccount1.print();
//        Next line will return Invalid withdraw amount!
//        currentAccount1.withdraw(11);
        System.out.println(currentAccount1.toString());

        System.out.println("\n---------#5---------");
        currentAccount1.print();
        currentAccount1.deposit(10);
        currentAccount1.print();
        currentAccount1.withdraw(10);
        currentAccount1.print();
        System.out.println(currentAccount1.getBalance());
        System.out.println(currentAccount1.getAccountNumber());




    }
}
