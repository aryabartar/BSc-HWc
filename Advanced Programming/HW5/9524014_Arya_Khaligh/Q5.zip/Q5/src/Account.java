public class Account {

    private long balance;// The current balance
    private long accountNumber;  // The account number

    public Account(long num) {
        balance = 0;
        accountNumber = num;
    }

    public void deposit(long amount) {
        if (amount > 0)
            balance += amount;
        else
            System.err.println("Invalid deposit amount!");
    }

    public void withdraw(long amount) {
        if (amount > 0 && amount <= balance)
            balance -= amount;
        else
            System.err.println("Invalid withdraw amount!");
    }

    public long getBalance() {
        return balance;
    }

    public long getAccountNumber() {
        return accountNumber;
    }

    public String toString() {
        return "Account Number #" + accountNumber
                + "--> balance = " + balance;
    }

    public final void print() {
        // Don't override this.
        // Override the toString method.
        System.out.println(toString());
    }
}