import java.util.ArrayList;

/**
 * This class saves accounts and perform tasks on them .
 * @author Arya Khaligh
 * @version 1.0
 */
public class Bank {

    private ArrayList<Account> array = new ArrayList<>() ;

    /**
     * This method adds accounts to bank .
     * @param account
     */
    public void addAccount (Account account) {
        array.add(account) ;
    }

    /**
     * This method perform certain tasks on accounts. If an account is an instance of SavingsAccount
     * calls method depositInterestRate and when is an instance of CurrentAccount calls print method .
     */
    public void update () {
        for (Account currentAccount : array) {
            if (currentAccount instanceof SavingsAccount){
                ((SavingsAccount) currentAccount).depositInterestRate();
            }

            if (currentAccount instanceof CurrentAccount) {
                CurrentAccount temp = (CurrentAccount) currentAccount ;
                if (temp.getBalance() < temp.getOverdraftLimit()){
                    temp.print();
                }
            }
        }
    }

}
