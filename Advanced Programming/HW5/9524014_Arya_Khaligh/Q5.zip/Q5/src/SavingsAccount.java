/**
 * This class extends Account class and adds interest rate and appropriate methods .
 *
 * @author Arya Khaligh
 * @version 1.0
 */
public class SavingsAccount extends Account {

    private double interestRate;

    /**
     * This constructor initializes superclass and interest rate variable .
     * @param num
     * @param interestRate
     */
    public SavingsAccount(long num, double interestRate) {
        super(num);

        if (interestRate >= 0)
            this.interestRate = interestRate;
        else
            throw new IllegalArgumentException("Wrong interest rate !");
    }

    /**
     * This class overrides to string method and returns class String .
     */
    @Override
    public String toString() {
        return super.toString() + "--> interest rate = " + getInterestRate();
    }

    /**
     * This method returns interestRate field .
     * @return interestRate
     */
    public double getInterestRate() {
        return interestRate;
    }

    /**
     * This method deposits interest amount to account .
     */
    public void depositInterestRate() {

        long depositAmount = (long) ((double)super.getBalance() * getInterestRate());
        super.deposit(depositAmount);
    }
}
