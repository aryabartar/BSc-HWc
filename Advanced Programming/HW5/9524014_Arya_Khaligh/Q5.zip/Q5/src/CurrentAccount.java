/**
 * This class extends Account class and adds overdraftLimit to it .
 * @author Arya Khaligh
 * @version 1.0
 */
public class CurrentAccount extends Account {
    private long overdraftLimit;

    /**
     * This constructor initializes superclass and overdraftLimit variables .
     * @param num for superclass
     * @param overdraftLimit for our field
     */
    public CurrentAccount(long num, long overdraftLimit) {
        super(num);
        if (overdraftLimit >= 0)
            this.overdraftLimit = overdraftLimit;
        else
            throw new IllegalArgumentException("Wrong overdraft limit!");
    }

    /**
     * This methos returns overdraftLimit field .
     * @return overdraftLimit
     */
    public long getOverdraftLimit() {
        return overdraftLimit;
    }

    /**
     * This method overrides superclass toString method and returns
     * appropriate String for this class .
     * @return appropriate string for class .
     */
    @Override
    public String toString() {
        return super.toString() + "--> overdraft limit = " + getOverdraftLimit();
    }
    /**
     * This method overrides superclass toString method and implements
     * acceptable withdraw amount .
     */

    @Override
    public void withdraw(long amount) {
        if (amount > 0 && overdraftLimit <= (getBalance() - amount))
            super.withdraw(amount);
        else
            System.err.println("Invalid withdraw amount!");
    }
}
