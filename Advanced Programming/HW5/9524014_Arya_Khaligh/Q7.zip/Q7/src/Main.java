import java.util.Queue;

/**
 * This method makes objects and tests their methods .
 * @author Arya Khaligh
 * @version 1.0
 */
public class Main {
    public static void main(String[] args) {
        SimplePersonQueue spq = new SimplePersonQueue();
        Person person1 = new Person("Seyed", "Ahmadpanah");
        Person person2 = new Person("Arya", "Khaligh");
        Person person3 = new Person("Parham" , "Alvani");

        if (spq instanceof Queue) {
            System.out.println("LinkedPersonQueue is an Queue");
        }

        if (spq.peek ()== null) {
            System.out.println("Queue is empty");
        }

        System.out.println("Is queue empty ? : " + spq.isEmpty());
//        spq.element() ;
        System.out.println("Peek testing : " + spq.peek());
//        spq.remove() ;
        System.out.println("Poll testing : " + spq.poll());

        spq.add(new Person("Seyed", "Ahmadpanah"));
        spq.add(new Person("Parham", "Alvani"));

        if (spq.element().equals(new Person("Parham", "Alvani"))) {
            System.out.println("Parham is on the head of queue");
        }

        if (spq.element().equals(new Person("Seyed", "Ahmadpanah"))) {
            System.out.println("Seyed is on the head of queue");
        }

        System.out.println("Is queue empty ? : " + spq.isEmpty());
        System.out.println("Queue size = " + spq.size());
        System.out.println(spq.element().toString());
        System.out.println(spq.element().toString());
        System.out.println(spq.contains(person1));
        System.out.println(spq.contains(person2));
        {
            System.out.println("\n\n------- Adding and removing test ---------");
            System.out.println(spq.remove(person1));
            System.out.println(spq.size());
            spq.add(person1);
            System.out.println("After adding new person : " + spq.size());
            System.out.println(spq.remove().toString());
            spq.add(person3) ;
            System.out.println("After adding new person : " + spq.size());
            System.out.println(spq.poll().toString());
            spq.add(person1) ;
            System.out.println("After adding new person : " + spq.size());
            System.out.println("------------------------------------------");
        }

        spq.peek();
        spq.peek();

        if (spq.size() == 0) {
            System.out.println("Queue is empty");
        }

        System.out.println(spq.peek().toString());
        spq.clear();

        if (spq.size() == 0) {
            System.out.println("Queue is empty");
        }
    }
}
