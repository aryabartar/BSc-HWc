public class Person {
    private String firstName;
    private String lastName;

    public Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * This method checks first name and last name equality .
     * @param person1 Checks these persons .
     * @return true if they are equal .
     */
    public boolean equals (Object person1) {
        Person person = (Person) person1 ;
        if ((person.firstName == this.firstName) && (person.lastName == this.lastName))
            return true ;
        else
            return false ;
    }

    /**
     * This class returns first name and last name .
     * @return firstname + lastname
     */
    @Override
    public String toString() {
        return "Person's first name : " + firstName + " / Person's last name : " + lastName ;
    }
}
